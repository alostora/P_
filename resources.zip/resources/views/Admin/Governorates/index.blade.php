
@include('Admin.header')
@include('Admin.leftSideBar')
@include('Admin.Governorates.Views.table')
 @include('Admin.footer')

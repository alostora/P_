
@include('Admin.header')
@include('Admin.leftSideBar')
@include('Admin.Areas.Views.edit')
@include('Admin.footer')


@include('Admin.header')
@include('Admin.leftSideBar')
@include('Admin.Areas.Views.table')
 @include('Admin.footer')

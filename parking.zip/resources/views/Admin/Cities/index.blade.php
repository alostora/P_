
@include('Admin.header')
@include('Admin.leftSideBar')
@include('Admin.Cities.Views.table')
 @include('Admin.footer')

<?php

namespace App\Http\Resources\Api;

use App\Constants\Api\ParkingTypes;
use App\Http\Resources\Admin\Garage\GarageMinifiedResource;
use App\Http\Resources\UserMinifiedResource;
use Illuminate\Http\Resources\Json\JsonResource;

class ParkingResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        return [

            'id' => $this->id,

            'clientName' => $this->clientName,

            'clientCarNumber' => $this->clientCarNumber,

            'clientIdentificationNumber' => $this->clientIdentificationNumber,

            'licenceNumber' => $this->licenceNumber,

            'clientPhone' => $this->clientPhone,

            'code' => $this->code,

            'type' => ParkingTypes::TYPE_LIST[$this->type ?? 0],

            'cost' => $this->cost,

            'notes' => $this->notes,

            'starts_at' => $this->starts_at,

            'ends_at' => $this->ends_at,

            'saies' => new UserMinifiedResource($this->saies),

            'garage' => new GarageMinifiedResource($this->garage),


            'print_text' => 'id : ' . $this->id . ' ' . 'clientName : ' . $this->clientName . ' ' . 'cost : ' . $this->cost . '
            
                What is Lorem Ipsum?

                Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.
            ',

        ];
    }
}
